---
name: one-hook
description: One hook
metadata: {"genesis":{"events":["command:new"]}}
---

# One Hook