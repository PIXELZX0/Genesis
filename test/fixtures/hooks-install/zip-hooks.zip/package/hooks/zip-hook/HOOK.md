---
name: zip-hook
description: Zip hook
metadata: {"genesis":{"events":["command:new"]}}
---

# Zip Hook