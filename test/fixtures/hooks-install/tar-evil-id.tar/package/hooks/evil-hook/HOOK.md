---
name: evil-hook
description: evil-hook
metadata: {"genesis":{"events":["command:new"]}}
---

# Hook