---
name: tar-hook
description: tar-hook
metadata: {"genesis":{"events":["command:new"]}}
---

# Hook