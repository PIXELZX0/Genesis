---
name: reserved-hook
description: reserved-hook
metadata: {"genesis":{"events":["command:new"]}}
---

# Hook